# B1 C1 packet v2 - a-miracle full (en+7) + healing v2 corrections
Date: 2026-10-23 ~05:04 EDT. Lane: locale/translation certification prep (unpublished). Base: b77f2f16 (PR #876). Branch b1-recovery.

## Contents
1. A-MIRACLE full mirror (new):
   - templates/mirrors/saint-charbel-prayer-for-a-miracle.html (144 slots: 87 page + 47 header + 10 locale plumbing)
   - locales/{en,ar,fr,es,de,it,pl,pt}/mirrors/saint-charbel-prayer-for-a-miracle.json (134 keys each)
   - Commits: 299a6e81 (template+en), 91f15cd2 (template fidelity fixes), bf9a644b (7 locale catalogs)
2. HEALING v2 corrections (supersede the 04:49 packet files):
   - templates/mirrors/saint-charbel-prayer-for-healing.html + all 8 healing catalogs
   - Commits: 83ea140f (template+en), 9cacb0ce (7 locale catalogs)
   - Found by the strengthened a-miracle verification (deep ld+json diff):
     a) live healing page has a 4-question FAQPage JSON-LD script the v1 template lacked -> added with new slots faq.bestLd / faq.dayLd (LD texts differ slightly from visible text); other two answers reuse faq.nonreligiousBody / faq.oilBody.
     b) live breadcrumb item3 name = full page h1 ("Saint Charbel Prayer for Healing"), not the nav label -> breadcrumb now {{hero.heading}}.
     c) live WebPage JSON-LD has no inLanguage key -> removed.
   - healing v1 shipped packet is MISSING FAQPage structured data until these files replace it.

## Verification (renderer-accurate fill, incl. JSON-context escaping per scripts/i18n/mirror.py)
A-miracle EN vs live saint-charbel-prayer-for-a-miracle.html: main text, title, footer, (tag,class) histogram, attribute values (alt/src/dim/loading), link list, and deep ld+json (WebPage+FAQPage) all match; only locale-plumbing slots differ by construction.
- Attested quotes byte-match certified day-1 novena catalogs 8/8 x 5 keys (petition-before/placeholder/petition-after/collect + elided FAQ quote). NOTE: Arabic petition-after carries the glory-of-God clause EN omits; attested bytes used per rulings.
- All 8 locales: slot==key, no missing, no extras, no blanks, no unresolved slots, both ld+json scripts parse.
Known non-rendering divergences from live EN source (browsers render identically): live uses single-quoted attrs in the CTA row; live healing source has one stray space after <p>. Left as-is.

## Flags for Scrum/integration (unchanged)
en+7 proposed batch scope, draft slugs unregistered, certification records pending Scrum gate, EN-master mirror conversion decision at integration time, sitemap lastmod handled generator-side at integration.
Records language: "AI review; native-speaker requirement waived by owner 2026-10-22 16:23 EDT". Not native-validated.
