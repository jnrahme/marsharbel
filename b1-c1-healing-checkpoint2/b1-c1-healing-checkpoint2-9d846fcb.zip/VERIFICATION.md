# B1 C1 healing mirror - checkpoint 2 (unpublished preparation, 2026-10-23 ~04:30 EDT)

Files:
- templates/mirrors/saint-charbel-prayer-for-healing.html (169 slots: 112 page + 47 header chrome + 10 locale plumbing)
- locales/en/mirrors/saint-charbel-prayer-for-healing.json (159 keys: 47 header + 112 page - translation source-of-truth)
- locales/ar/mirrors/saint-charbel-prayer-for-healing.json (159 keys, first locale)

Verification (fresh, scripted):
- Slot set == catalog key set exactly (0 missing, 0 extra).
- EN fill of the template vs the live EN page: main text, <title>, footer, tag histogram,
  and link (text+href) parity ALL MATCH.
- AR fill renders with no unresolved slots; no blank strings.
- The Annaya novena incipit quoted in faq.bestBeforeLink uses the byte-exact attested form
  from the live certified locales/ar/saint-charbel-novena-master-copy.json
  ("أيها القدّيس شربل العجائبي... هلمَّ إلى معونتي" - diacritic order matched to source).
- Shared chrome (header.*) copied verbatim from the attested live ar/en prayers catalogs.
- Terminology from live attested catalogs only: مار شربل, الثاني والعشرين من كل شهر, نهاد الشامي,
  site-composition label mirrors the attested labeling.originalExplanation phrasing.

Review class: AI review; native-speaker requirement waived by owner 2026-10-22 16:23 EDT.
Not native-validated. Not certified. Slugs/routes untouched. Local commits on b1-recovery:
2f390eb2 (template+en), 2b4c1a8b (ar).
